pred spusteni uzij tohoto kodu:

venv\Scripts\activate
